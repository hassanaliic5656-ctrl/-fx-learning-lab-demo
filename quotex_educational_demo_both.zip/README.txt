# FX Learning Lab — educational demo

## Website
Open `index.html` in a browser. It is a static learning dashboard with simulated examples only.

## Telegram learning bot
1. Create a bot through Telegram's official BotFather.
2. Keep the bot token private. Never paste it into a public chat or website.
3. Install Python 3.10+ and run: `pip install python-telegram-bot`
4. Set the environment variable `TELEGRAM_BOT_TOKEN` to your token.
5. Run: `python telegram_bot.py`

The Telegram starter uses polling and needs a computer/server running while it is active.
This project intentionally has no Quotex integration, live signals, BUY/SELL calls,
account credentials, deposits, or automated trading.
