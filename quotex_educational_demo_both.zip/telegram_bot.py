"""
Telegram learning bot starter.
It teaches trading terminology only; it does NOT issue BUY/SELL signals,
connect to Quotex, fetch prices, or place trades.
"""
import os
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Welcome to FX Learning Lab (education only).\\n"
        "Commands: /lesson /quiz /risk"
    )

async def lesson(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Candlestick basics:\\n"
        "• Body: open-to-close range\\n"
        "• Wicks: high and low\\n"
        "A candle does not guarantee the next price move."
    )

async def quiz(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Quick quiz: What do candlestick wicks show?\\n"
        "A) High and low\\nB) Guaranteed future price\\n"
        "Reply to yourself: A is correct."
    )

async def risk(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Risk reminder: this bot is educational only. No real-money trades, "
        "broker login, deposits, or guaranteed signals. Short-expiry trading "
        "can lead to rapid losses."
    )

def main():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError("Set TELEGRAM_BOT_TOKEN as an environment variable.")
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("lesson", lesson))
    app.add_handler(CommandHandler("quiz", quiz))
    app.add_handler(CommandHandler("risk", risk))
    app.run_polling()

if __name__ == "__main__":
    main()
